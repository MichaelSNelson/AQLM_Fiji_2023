from math import sqrt
import xml.dom.minidom
from java.awt import Color
from ij.gui import Plot

# Open file and parse it as XML.
folder_path = '/Users/tinevez/Desktop/MadisonTrackingTutorial/'
# folder_path= '/Users/tinevez/Google Drive/Cours/GettingStartedInImageAnalysis/Materials/J. Tracking objects over time'
file_path = folder_path + 'DaphniaSp-1-Tracks.xml'
dom = xml.dom.minidom.parse(file_path)

# Get all particles. But we keep only the first one.
particles = dom.getElementsByTagName('particle')
daphnia = particles[0]

# Extract the Y coordinate over time of this daphnia.
t = [];
y = [];
spots = daphnia.getElementsByTagName('detection')
for s in spots:
	t.append( int( s.getAttribute('t') ) )
	y.append( float( s.getAttribute('y') ) )

# Plot it using IJ graphs.
plot = Plot("Channel position over time", "frame", "position (um)")
plot.setColor(Color.RED)
plot.addPoints(t, y, Plot.LINE)
plot.show()

# Compute derivative
V = []
tV = t[:-1]
for i in range( len( y ) - 1 ):
	V.append( y[i+1] - y[i] )

# Plot velocity.
plot = Plot("Velocity over time", "frame", "V (um/frame)")
plot.setColor(Color.BLUE)
plot.addPoints(tV, V, Plot.LINE)
plot.show()

# Detect pulses: velocity gets below -2.
beats = []
for i in range( len( V ) ):
	if V[i] < -2:
		beats.append( 1 )
	else:
		beats.append( 0 )

# Then we say that a pulse is when the beat function goes from 0 to 1.
pulses = []
for i in range( len( beats) - 1 ):
	db = beats[i+1] - beats[i]
	if db > 0:
		pulses.append( tV[i] )

# Then we compute the delta T between two pulses.
deltaT = []
for i in range( len( pulses ) - 1 ):
	deltaT.append( pulses[i+1] - pulses[i] )

# Get mean and std.
N = len( deltaT )
mean = sum( deltaT ) / float(N)
std = sqrt( sum( (x - mean)**2 for x in deltaT) / float(N) )

print('----------------------------------------------------------')
print( 'Average beating period: %.2f +/- %.2f frames (N = %d).' % ( mean, std, N ) )
print('----------------------------------------------------------')
